<?php
// a working php mail script!

// get the data give it some basic formatting and assign it to a variable
$name = trim($_POST['email']);


//Email address that the message is going
$to = 'kristi.greenoe@snapav.com';

//What is the subject of the Email
$subject = 'OvrC Pro Interest';

//Set where the redirect will go after form is completed
$url = 'http://ovrc.com/overview.html';

//Basic html formatting of the message using the variables above 
$content = 
"<html>
   <body> 
     <p>
         $email<br>
     </p>
   </body>
</html>";

//All the header info (there are more options not listed)
$header = "From:$name\n" .
          //this is to make the form data and html work
          "MIME-Version: 1.0\n" .
          "Content-type: text/html; charset=iso-8859-1";
//The function that does the work
mail($to,$subject,$content,$header);
//Redirect command
echo '<META HTTP-EQUIV=Refresh CONTENT="0; URL='.$url.'">';
?>